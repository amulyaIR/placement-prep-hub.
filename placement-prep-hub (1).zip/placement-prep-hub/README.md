# Placement Prep Hub

A Pen created on CodePen.

Original URL: [https://codepen.io/Amulya-IR/pen/LEpdPJy](https://codepen.io/Amulya-IR/pen/LEpdPJy).

“Placement preparation hub with MCQs, interview questions, and coding resources.”